public class Node {
    Person person;
    Node next;

    Node(Person person) {
        this.person = person;
        this.next = null;
    }
}
